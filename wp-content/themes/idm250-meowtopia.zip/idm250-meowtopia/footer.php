</main>
<footer>
    <div id="footer-flex">
        <p id="footer-logo">Meowtopia</p>
        <div id="footer-contact">
            <p>Tel: +1 (123) 456-789</p>
            <p>Email: meowtopia@gmail.com</p>
        </div>
    </div>
    <p id="copyright">&copy; 2024 Kaylie Nguyen </p>
</footer>

<?php wp_footer(); ?>

</body>
</html>