<?php get_header(); ?>

<!-- <h1><?php echo get_the_title(); ?></h1> -->

<div class="content">
    <?php echo get_the_content(); ?>
</div>

<?php get_footer(); ?>